import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Wwedite pogaluista kolichestwo polnich let progitich wami w brake: ");
        int weddNum = scr.nextInt();
        String message = switch (weddNum) {
            case 1 -> concat(Wedding.ONE);
            case 2 -> concat(Wedding.TWO);
            case 3 -> concat(Wedding.THREE);
            case 4 -> concat(Wedding.FOUR);
            case 5 -> concat(Wedding.FIVE);
            case 6 -> concat(Wedding.SIX);
            case 7 -> concat(Wedding.SEVEN);
            case 8 -> concat(Wedding.EIGHT);
            case 9 -> concat(Wedding.NINE);
            case 10 -> concat(Wedding.TEN);
            case 11 -> concat(Wedding.ELEVEN);
            case 12 -> concat(Wedding.TWELVE);
            case 13 -> concat(Wedding.THIRTEEN);
            case 14 -> concat(Wedding.FOURTEEN);
            default -> "W dannoi base takoe snachenie otsutstwuet, poprobuite snowa.";
        };
        System.out.println("Tekuschaja eto" + " " + message);
    }

    public static String concat(Wedding wed) {
        return wed.getDescription();
    }
}