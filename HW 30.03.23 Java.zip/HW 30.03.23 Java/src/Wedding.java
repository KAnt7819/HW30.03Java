import javax.imageio.plugins.jpeg.JPEGHuffmanTable;
import javax.swing.plaf.FontUIResource;

public enum Wedding {

    ONE("sitcewaja swadba - sledujuschaja budet bumagnaja."),
    TWO("bumagnaja swadba - sledujuschaja budet kogannaja."),
    THREE("kogannaja swadba - sledujuschaja budet l'njanaja."),
    FOUR("l'njanaja swadba - sledujuschaja budet derewjannaja."),
    FIVE("derewjannaja swadba - sledujuschaja budet chugunnaja."),
    SIX("chugunnaja swadba - sledujuschaja budet mednaja."),
    SEVEN("mednaja swadba - sledujuschaja budet gestjanaja."),
    EIGHT("gestjanaja swadba - sledujuschaja budet fajansowaja."),
    NINE("fajansowaja swadba - sledujuschaja budet olowjannaja."),
    TEN("olowjannaja swadba - sledujuschaja budet stalnaja."),
    ELEVEN("stalnaja swadba - sledujuschaja budet nikelewaja."),
    TWELVE("nikelewaja swadba - sledujuschaja budet krugewnaja."),
    THIRTEEN("krugewnaja swadba - sledujuschaja budet agatowaja."),
    FOURTEEN("agatowaja swadba - sledujuschaja budet chrustalnaja.");
    private final String description;

    public String getDescription()
    {
        return description;
    }

    Wedding(String description){
        this.description = description;

    }
}
